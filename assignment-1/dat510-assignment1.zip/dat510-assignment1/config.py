plaintext = "Andreas Pedersen Security and Vulnerability in Networks"
numeric_key = 13452
numeric_key_list = [1,3,4,5,2]
caesar_key = 2